(function () {
  var side = document.getElementById('sidebar');
  var scrim = document.querySelector('.scrim');
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (t.closest && t.closest('[data-menu]')) {
      side.classList.toggle('open');
      scrim.classList.toggle('open');
      return;
    }
    if (t.matches && t.matches('img[data-lightbox]')) {
      var box = document.createElement('div');
      box.className = 'lb';
      var big = document.createElement('img');
      big.src = t.src;
      big.alt = t.alt;
      box.appendChild(big);
      box.addEventListener('click', function () { box.remove(); });
      document.body.appendChild(box);
    }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      var lb = document.querySelector('.lb');
      if (lb) lb.remove();
    }
  });
})();

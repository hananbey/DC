const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dtc-'));
process.env.DB_FILE = path.join(tmp, 'test.db');
process.env.ADMIN_EMAIL = 'admin@test.com';
process.env.ADMIN_PASSWORD = 'a-long-test-password';

let server, base, cookie = '', csrf = '';

before(async () => {
  require('../src/seed.js');
  const app = require('../src/server.js');
  await new Promise((r) => { server = app.listen(0, r); });
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

const get = (p, opts = {}) => fetch(base + p, { redirect: 'manual', ...opts, headers: { cookie, ...(opts.headers || {}) } });

async function login() {
  const res = await fetch(base + '/admin/login', {
    method: 'POST', redirect: 'manual',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ email: 'admin@test.com', password: 'a-long-test-password' }),
  });
  assert.equal(res.status, 302);
  cookie = res.headers.get('set-cookie').split(';')[0];
  const dash = await (await get('/admin')).text();
  csrf = /name="_csrf" value="([a-f0-9]+)"/.exec(dash)[1];
}

test('public pages render with seeded content', async () => {
  for (const p of ['/', '/services/wedding', '/shop', '/booking', '/shop/lights']) {
    const res = await get(p);
    assert.equal(res.status, 200, p);
  }
  const home = await (await get('/')).text();
  assert.match(home, /Decorate To Celebrate/);
  assert.match(home, /Wedding/);
  const wedding = await (await get('/services/wedding')).text();
  assert.match(wedding, /Dholki/);
  assert.equal((await get('/nope')).status, 404);
});

test('admin is protected and login works', async () => {
  const res = await get('/admin');
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), '/admin/login');
  const bad = await fetch(base + '/admin/login', { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ email: 'admin@test.com', password: 'wrong' }) });
  assert.match(bad.headers.get('location'), /error=/);
  await login();
  assert.equal((await get('/admin/services')).status, 200);
});

test('forms without a CSRF token are rejected', async () => {
  const res = await get('/admin/categories', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ name: 'Hack', type: 'service' }) });
  assert.equal(res.status, 403);
});

test('admin can add a service with photos and it appears on the website', async () => {
  const sharp = require('sharp');
  const png = await sharp({ create: { width: 1600, height: 900, channels: 3, background: '#5a0a14' } }).png().toBuffer();
  const cat = JSON.parse(JSON.stringify(require('../src/db').prepare("SELECT id FROM categories WHERE type='service' AND slug='wedding'").get()));
  const form = new FormData();
  form.set('_csrf', csrf);
  form.set('name', 'Test <b>Entrance</b> Decor');
  form.set('category_id', String(cat.id));
  form.set('summary', 'A test summary');
  form.set('description', 'Line one\nLine two <script>alert(1)</script>');
  form.set('sort', '0');
  form.set('visible', '1');
  form.set('banner', new Blob([png], { type: 'image/png' }), 'banner.png');
  form.append('gallery', new Blob([png], { type: 'image/png' }), 'g1.png');
  form.append('gallery', new Blob([Buffer.from('not an image')], { type: 'image/png' }), 'fake.png');
  const res = await get('/admin/services', { method: 'POST', body: form });
  assert.equal(res.status, 302, await res.text());
  const page = await (await get('/service/test-b-entrance-b-decor')).text();
  assert.match(page, /Test &lt;b&gt;Entrance&lt;\/b&gt; Decor/);      // escaped, not raw HTML
  assert.ok(!page.includes('<script>alert(1)</script>'));            // script is escaped
  assert.match(page, /Line one<br \/>\s*Line two/);                  // line breaks kept
  const imgs = page.match(/\/uploads\/[a-f0-9]{16}\.webp/g) || [];
  assert.ok(imgs.length >= 2, 'banner and one valid gallery photo are shown');
  const file = await get(imgs[0]);
  assert.equal(file.status, 200);
  assert.match(file.headers.get('content-type'), /webp/);
});

test('appearance settings change the live site', async () => {
  const res = await get('/admin/appearance', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ _csrf: csrf, primary: '#112233', dark: '#0d0d0d', light: '#faf7f2', accent: '#c9a24b', heading_font: 'Playfair Display', body_font: 'Poppins', hero_title: 'New hero heading', hero_text: 'Hello', hero_image_url: 'javascript:alert(1)' }) });
  assert.equal(res.status, 302);
  const home = await (await get('/')).text();
  assert.match(home, /--maroon:#112233/);
  assert.match(home, /New hero heading/);
  assert.ok(!home.includes('javascript:alert'));
});

test('site settings change the live site', async () => {
  const form = new FormData();
  form.set('_csrf', csrf);
  form.set('business_name', 'Decorate To Celebrate');
  form.set('whatsapp', '+92 370 7671414');
  form.set('jazzcash_number', '0300 0000000');
  form.set('announcement', 'Eid offers now open');
  form.set('instagram', 'not-a-link');
  const res = await get('/admin/settings', { method: 'POST', body: form });
  assert.equal(res.status, 302);
  const home = await (await get('/')).text();
  assert.match(home, /Eid offers now open/);
  assert.match(home, /wa\.me\/923707671414/);
  const booking = await (await get('/booking')).text();
  assert.match(booking, /0300 0000000/);
});

test('logout ends the session', async () => {
  const res = await get('/admin/logout', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ _csrf: csrf }) });
  assert.equal(res.status, 302);
  assert.equal((await get('/admin')).status, 302);
});

document.addEventListener('submit', function (e) {
  var f = e.target;
  if (f.classList && f.classList.contains('js-confirm')) {
    if (!window.confirm(f.getAttribute('data-confirm') || 'Are you sure?')) e.preventDefault();
  }
});
document.addEventListener('click', function (e) {
  if (e.target.closest && e.target.closest('[data-menu]')) {
    document.getElementById('side').classList.toggle('open');
  }
});

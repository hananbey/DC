# DTC Studio (Milestone 1 + 2)

A small self-hosted website platform for Decorate To Celebrate:
a backend + admin panel, and a website that is drawn by a theme.
Free to run. No WordPress, no Hostinger, no Supabase.

## What works in this version
- Admin login (password hashed, sessions, CSRF protection, login rate limit)
- Admin panel: Services, Products, Categories, Photos, Appearance (theme settings), Site settings, Account
- Photos are resized to WebP (max 1200 px) automatically
- Public website drawn by the "DTC Luxe" theme (side menu, home, category pages, service pages with gallery,
  shop, product pages, booking info page), mobile friendly
- Changes in the admin panel show on the website immediately

## Not built yet (next milestones)
- Theme zip upload, preview, publish and rollback (Milestone 3)
- Customer login, "Add to Form", booking form with reference pictures, cart, checkout, payment screenshot, orders inbox (Milestones 4 and 5)
- Going online on a free server with your Namecheap domain (Milestone 6)

## Run it on your laptop
1. Install Node.js LTS (version 20 or newer) from https://nodejs.org
2. Open a terminal in this folder and run:
       npm install
3. Copy `.env.example` to `.env`, open it, and set ADMIN_EMAIL and a long ADMIN_PASSWORD (10+ characters).
4. Run:
       npm run setup
   (creates your admin user and the starter categories, services and shop items)
5. Run:
       npm start
6. Open http://localhost:3000 (website) and http://localhost:3000/admin (admin panel).

## Run the automatic tests
       npm test

## Folder guide
- src/            backend code (server, database, admin routes, public routes, themes)
- views/admin/    admin panel pages
- public/admin/   admin panel CSS and JS
- themes/dtc-luxe/  the theme: theme.json (settings), layout/, templates/, sections/, assets/
- data/           the SQLite database file (back this up!)
- uploads/        your uploaded photos (back this up!)

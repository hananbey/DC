const express = require('express');
const path = require('path');
const db = require('./db');
const themes = require('./themes');

const router = express.Router();
const PROD = process.env.NODE_ENV === 'production';

const img = (f) => (f ? `/uploads/${f}` : '');
const parseList = (s) => { try { const a = JSON.parse(s || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } };
const money = (n) => (n === null || n === undefined ? 'Price on request' : `Rs ${Number(n).toLocaleString('en-PK')}`);

function siteContext(req) {
  const s = db.getSettings();
  const digits = String(s.whatsapp || '').replace(/\D/g, '');
  const origin = `${req.protocol}://${req.get('host')}`;
  return {
    ...s,
    origin,
    qr_url: img(s.qr_image),
    wa_link: digits ? `https://wa.me/${digits}` : '',
    tel_link: s.phone ? `tel:${String(s.phone).replace(/\s+/g, '')}` : '',
    mail_link: s.email ? `mailto:${s.email}` : '',
    wa_digits: digits,
  };
}
function waLink(site, text) {
  return site.wa_digits ? `https://wa.me/${site.wa_digits}?text=${encodeURIComponent(text)}` : '';
}
function mapService(s, site) {
  const gallery = parseList(s.gallery).map(img);
  return {
    id: s.id, name: s.name, slug: s.slug, summary: s.summary, description: s.description,
    banner_url: img(s.banner), gallery, images: [img(s.banner), ...gallery].filter(Boolean),
    cat_name: s.cat_name, cat_slug: s.cat_slug, url: `/service/${s.slug}`,
    whatsapp_url: waLink(site, `Assalam o Alaikum! I am interested in "${s.name}". ${site.origin}/service/${s.slug}`),
  };
}
function mapProduct(p, site) {
  const photos = parseList(p.photos).map(img);
  return {
    id: p.id, name: p.name, slug: p.slug, description: p.description, price: p.price,
    price_text: money(p.price), stock: p.stock, photos, photo: photos[0] || '',
    cat_name: p.cat_name, cat_slug: p.cat_slug, url: `/product/${p.slug}`,
    whatsapp_url: waLink(site, `Assalam o Alaikum! I would like to order "${p.name}". ${site.origin}/product/${p.slug}`),
  };
}

const SERVICE_SELECT = `SELECT s.*, c.name AS cat_name, c.slug AS cat_slug FROM services s JOIN categories c ON c.id = s.category_id WHERE s.visible = 1`;
const PRODUCT_SELECT = `SELECT p.*, c.name AS cat_name, c.slug AS cat_slug FROM products p JOIN categories c ON c.id = p.category_id WHERE p.visible = 1`;

function baseData(req, extra = {}) {
  const site = siteContext(req);
  const theme = themes.themeSettings(themes.activeThemeName());
  const serviceCats = db.prepare(`SELECT * FROM categories WHERE type = 'service' ORDER BY sort, id`).all();
  return {
    site, theme, path: req.path,
    nav: serviceCats.map((c) => ({ name: c.name, url: `/services/${c.slug}`, slug: c.slug })),
    year: new Date().getFullYear(),
    ...extra,
  };
}
async function page(req, res, template, extra, status = 200) {
  const html = await themes.renderPage(themes.activeThemeName(), template, baseData(req, extra));
  res.status(status).send(html);
}

router.use('/theme-assets', (req, res, next) => {
  const dir = path.join(themes.THEMES_DIR, themes.activeThemeName(), 'assets');
  return express.static(dir, { maxAge: PROD ? '7d' : 0, index: false })(req, res, next);
});

router.get('/', async (req, res) => {
  const site = siteContext(req);
  const cats = db.prepare(`SELECT * FROM categories WHERE type = 'service' ORDER BY sort, id`).all();
  const sections = cats.map((c) => ({
    name: c.name, slug: c.slug, url: `/services/${c.slug}`,
    items: db.prepare(`${SERVICE_SELECT} AND s.category_id = ? ORDER BY s.sort, s.id LIMIT 4`).all(c.id).map((s) => mapService(s, site)),
  }));
  const shopCats = db.prepare(`SELECT * FROM categories WHERE type = 'product' ORDER BY sort, id`).all()
    .map((c) => ({ name: c.name, url: `/shop/${c.slug}` }));
  await page(req, res, 'index', { page_title: '', sections, shop_cats: shopCats });
});

router.get('/services/:slug', async (req, res, next) => {
  const site = siteContext(req);
  const cat = db.prepare(`SELECT * FROM categories WHERE type = 'service' AND slug = ?`).get(req.params.slug);
  if (!cat) return next();
  const items = db.prepare(`${SERVICE_SELECT} AND s.category_id = ? ORDER BY s.sort, s.id`).all(cat.id).map((s) => mapService(s, site));
  await page(req, res, 'category', { page_title: cat.name, category: cat, items });
});

router.get('/service/:slug', async (req, res, next) => {
  const site = siteContext(req);
  const row = db.prepare(`${SERVICE_SELECT} AND s.slug = ?`).get(req.params.slug);
  if (!row) return next();
  const related = db.prepare(`${SERVICE_SELECT} AND s.category_id = ? AND s.id != ? ORDER BY s.sort, s.id LIMIT 3`).all(row.category_id, row.id).map((s) => mapService(s, site));
  const item = mapService(row, site);
  await page(req, res, 'service', { page_title: item.name, page_description: item.summary, item, related });
});

async function shop(req, res, next) {
  const site = siteContext(req);
  const cats = db.prepare(`SELECT * FROM categories WHERE type = 'product' ORDER BY sort, id`).all();
  let current = null;
  let sql = `${PRODUCT_SELECT}`;
  const params = [];
  if (req.params.slug) {
    current = cats.find((c) => c.slug === req.params.slug);
    if (!current) return next();
    sql += ' AND p.category_id = ?'; params.push(current.id);
  }
  const q = String(req.query.q || '').trim().slice(0, 60);
  if (q) { sql += ` AND p.name LIKE ? ESCAPE '\\'`; params.push(`%${q.replace(/[\\%_]/g, '\\$&')}%`); }
  const products = db.prepare(`${sql} ORDER BY p.sort, p.id`).all(...params).map((p) => mapProduct(p, site));
  await page(req, res, 'shop', {
    page_title: current ? current.name : 'Shop Now', q, current,
    shop_cats: cats.map((c) => ({ name: c.name, slug: c.slug, url: `/shop/${c.slug}`, active: current && current.id === c.id })),
    products,
  });
}
router.get('/shop', shop);
router.get('/shop/:slug', shop);

router.get('/product/:slug', async (req, res, next) => {
  const site = siteContext(req);
  const row = db.prepare(`${PRODUCT_SELECT} AND p.slug = ?`).get(req.params.slug);
  if (!row) return next();
  await page(req, res, 'product', { page_title: row.name, item: mapProduct(row, site) });
});

router.get('/booking', (req, res) => page(req, res, 'booking', { page_title: 'Booking' }));

router.use(async (req, res) => {
  try { await page(req, res, '404', { page_title: 'Page not found' }, 404); }
  catch { res.status(404).send('Page not found'); }
});

module.exports = router;

const express = require('express');
const path = require('path');
const { Liquid } = require('liquidjs');
const db = require('./db');
const auth = require('./auth');
const themes = require('./themes');
const { upload, saveImage, deleteImage } = require('./media');
const { uniqueSlug } = require('./slug');

const router = express.Router();
const PROD = process.env.NODE_ENV === 'production';

const engine = new Liquid({
  root: path.join(__dirname, '..', 'views', 'admin'),
  extname: '.liquid',
  outputEscape: 'escape',
  cache: PROD,
});

function ctx(req, extra = {}) {
  return {
    csrf: req.session ? req.session.csrf : '',
    user: req.session,
    ok: String(req.query.ok || '').slice(0, 160),
    error: String(req.query.error || '').slice(0, 200),
    ...extra,
  };
}
async function view(req, res, name, extra = {}, status = 200) {
  const data = ctx(req, extra);
  const content = await engine.renderFile(name, data);
  const html = await engine.renderFile('layout', { ...data, content_for_layout: content });
  res.status(status).send(html);
}
const go = (res, url, ok) => res.redirect(`${url}${url.includes('?') ? '&' : '?'}ok=${encodeURIComponent(ok)}`);
const fail = (res, url, error) => res.redirect(`${url}${url.includes('?') ? '&' : '?'}error=${encodeURIComponent(error)}`);

router.use(express.urlencoded({ extended: false, limit: '300kb' }));

// ---------- login / logout ----------
router.get('/login', async (req, res) => {
  if (req.session) return res.redirect('/admin');
  const content = await engine.renderFile('login', ctx(req));
  res.send(content);
});
router.post('/login', auth.loginLimiter, (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !auth.verifyPassword(password, user.password_hash)) return fail(res, '/admin/login', 'Wrong email or password.');
  auth.clearLoginAttempts(req);
  auth.createSession(res, user.id);
  res.redirect('/admin');
});
router.post('/logout', auth.requireAdmin, auth.csrfCheck, (req, res) => {
  auth.destroySession(req, res);
  res.redirect('/admin/login');
});

// everything below needs an admin session
router.use(auth.requireAdmin);

router.get('/', (req, res) => {
  const count = (t) => db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
  view(req, res, 'dashboard', {
    title: 'Dashboard', active: 'dashboard',
    stats: [
      { label: 'Services', value: count('services'), url: '/admin/services' },
      { label: 'Products', value: count('products'), url: '/admin/products' },
      { label: 'Categories', value: count('categories'), url: '/admin/categories' },
      { label: 'Photos', value: count('media'), url: '/admin/media' },
    ],
    theme: themes.activeThemeName(),
  });
});

// ---------- categories ----------
router.get('/categories', (req, res) => {
  const rows = db.prepare(`SELECT c.*, (SELECT COUNT(*) FROM services s WHERE s.category_id = c.id) + (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS items FROM categories c ORDER BY type, sort, id`).all();
  view(req, res, 'categories', {
    title: 'Categories', active: 'categories',
    service_cats: rows.filter((r) => r.type === 'service'),
    product_cats: rows.filter((r) => r.type === 'product'),
  });
});
router.post('/categories', auth.csrfCheck, (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 80);
  const type = req.body.type === 'product' ? 'product' : 'service';
  if (!name) return fail(res, '/admin/categories', 'Please enter a category name.');
  const slug = uniqueSlug('categories', name, 'AND type = ?', [type]);
  const sort = db.prepare('SELECT COALESCE(MAX(sort), 0) + 1 AS n FROM categories WHERE type = ?').get(type).n;
  db.prepare('INSERT INTO categories(type, slug, name, sort) VALUES (?,?,?,?)').run(type, slug, name, sort);
  go(res, '/admin/categories', 'Category added.');
});
router.post('/categories/:id', auth.csrfCheck, (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 80);
  const sort = Number.parseInt(req.body.sort, 10) || 0;
  if (!name) return fail(res, '/admin/categories', 'Name cannot be empty.');
  db.prepare('UPDATE categories SET name = ?, sort = ? WHERE id = ?').run(name, sort, req.params.id);
  go(res, '/admin/categories', 'Category saved.');
});
router.post('/categories/:id/delete', auth.csrfCheck, (req, res) => {
  const id = Number(req.params.id);
  const used = db.prepare('SELECT (SELECT COUNT(*) FROM services WHERE category_id = ?) + (SELECT COUNT(*) FROM products WHERE category_id = ?) AS n').get(id, id).n;
  if (used > 0) return fail(res, '/admin/categories', 'This category still has items. Move or delete them first.');
  db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  go(res, '/admin/categories', 'Category deleted.');
});

// ---------- generic item resources (services, products) ----------
async function collect(req, cfg, existing) {
  const data = {};
  const files = req.files || {};
  for (const f of cfg.fields) {
    if (f.type === 'image') {
      let cur = existing ? existing[f.name] : '';
      if (req.body[`remove_${f.name}`]) cur = '';
      if (files[f.name] && files[f.name][0]) { try { cur = await saveImage(files[f.name][0]); } catch { /* skip bad file */ } }
      data[f.name] = cur || '';
    } else if (f.type === 'gallery') {
      let cur = existing ? JSON.parse(existing[f.name] || '[]') : [];
      const remove = [].concat(req.body[`remove_${f.name}`] || []);
      cur = cur.filter((x) => !remove.includes(x));
      for (const file of files[f.name] || []) { try { cur.push(await saveImage(file)); } catch { /* skip bad file */ } }
      data[f.name] = JSON.stringify(cur);
    } else if (f.type === 'checkbox') {
      data[f.name] = req.body[f.name] ? 1 : 0;
    } else if (f.type === 'number') {
      const raw = req.body[f.name];
      if (raw === undefined || raw === '') data[f.name] = f.nullable ? null : 0;
      else { const n = Number(raw); data[f.name] = Number.isFinite(n) && n >= 0 ? n : (f.nullable ? null : 0); }
    } else {
      data[f.name] = String(req.body[f.name] || '').trim().slice(0, f.max || 200);
    }
  }
  return data;
}

function fieldsFor(cfg, row) {
  const cats = db.prepare('SELECT id, name FROM categories WHERE type = ? ORDER BY sort, id').all(cfg.catType);
  return cfg.fields.map((f) => {
    let value = row ? row[f.name] : f.default;
    if (f.type === 'gallery') value = (() => { try { return JSON.parse(value || '[]'); } catch { return []; } })();
    if (f.type === 'checkbox') value = row ? !!row[f.name] : true;
    if (f.name === 'category_id') return { ...f, value: value || '', options: cats.map((c) => ({ value: c.id, label: c.name })) };
    return { ...f, value: value === null || value === undefined ? '' : value };
  });
}

function itemResource(cfg) {
  const base = `/admin/${cfg.table}`; // used for links and redirects
  const route = `/${cfg.table}`; // path inside this router (mounted at /admin)
  const files = upload.fields(cfg.fields.filter((f) => f.type === 'image' || f.type === 'gallery').map((f) => ({ name: f.name, maxCount: f.type === 'image' ? 1 : 8 })));
  const thumbOf = (r) => {
    const f = cfg.fields.find((x) => x.type === 'image' || x.type === 'gallery');
    if (!f) return '';
    if (f.type === 'image') return r[f.name];
    try { return JSON.parse(r[f.name] || '[]')[0] || ''; } catch { return ''; }
  };

  router.get(route, (req, res) => {
    const rows = db.prepare(`SELECT t.*, c.name AS cat_name FROM ${cfg.table} t JOIN categories c ON c.id = t.category_id ORDER BY c.sort, c.id, t.sort, t.id`).all();
    view(req, res, 'list', {
      title: cfg.plural, active: cfg.table, base, singular: cfg.singular,
      headers: cfg.cols.map((c) => c.label),
      rows: rows.map((r) => ({ id: r.id, thumb: thumbOf(r), cells: cfg.cols.map((c) => c.get(r)) })),
    });
  });
  router.get(`${route}/new`, (req, res) => {
    const cats = db.prepare('SELECT 1 FROM categories WHERE type = ?').get(cfg.catType);
    if (!cats) return fail(res, '/admin/categories', `Add a ${cfg.catType} category first.`);
    view(req, res, 'form', { title: `New ${cfg.singular}`, active: cfg.table, action: base, fields: fieldsFor(cfg, null), back: base, submit: `Add ${cfg.singular}` });
  });
  router.get(`${route}/:id/edit`, (req, res, next) => {
    const row = db.prepare(`SELECT * FROM ${cfg.table} WHERE id = ?`).get(req.params.id);
    if (!row) return next();
    view(req, res, 'form', { title: `Edit ${cfg.singular}`, active: cfg.table, action: `${base}/${row.id}`, fields: fieldsFor(cfg, row), back: base, submit: 'Save changes', delete_action: `${base}/${row.id}/delete`, view_url: `${cfg.publicPath}${row.slug}` });
  });
  router.post(route, files, auth.csrfCheck, async (req, res) => {
    const data = await collect(req, cfg, null);
    if (!data.name) return fail(res, `${base}/new`, 'Name is required.');
    if (!db.prepare('SELECT 1 FROM categories WHERE id = ? AND type = ?').get(data.category_id, cfg.catType)) return fail(res, `${base}/new`, 'Please choose a category.');
    data.slug = uniqueSlug(cfg.table, data.name);
    const cols = Object.keys(data);
    db.prepare(`INSERT INTO ${cfg.table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`).run(...cols.map((c) => data[c]));
    go(res, base, `${cfg.singular} added.`);
  });
  router.post(`${route}/:id`, files, auth.csrfCheck, async (req, res, next) => {
    const row = db.prepare(`SELECT * FROM ${cfg.table} WHERE id = ?`).get(req.params.id);
    if (!row) return next();
    const data = await collect(req, cfg, row);
    if (!data.name) return fail(res, `${base}/${row.id}/edit`, 'Name is required.');
    if (!db.prepare('SELECT 1 FROM categories WHERE id = ? AND type = ?').get(data.category_id, cfg.catType)) return fail(res, `${base}/${row.id}/edit`, 'Please choose a category.');
    const cols = Object.keys(data);
    db.prepare(`UPDATE ${cfg.table} SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = ?`).run(...cols.map((c) => data[c]), row.id);
    go(res, base, `${cfg.singular} saved.`);
  });
  router.post(`${route}/:id/delete`, auth.csrfCheck, (req, res) => {
    db.prepare(`DELETE FROM ${cfg.table} WHERE id = ?`).run(req.params.id);
    go(res, base, `${cfg.singular} deleted.`);
  });
}

itemResource({
  table: 'services', singular: 'Service', plural: 'Services', catType: 'service', publicPath: '/service/',
  fields: [
    { name: 'name', label: 'Name', type: 'text', required: true },
    { name: 'category_id', label: 'Category', type: 'select', required: true },
    { name: 'summary', label: 'Short line (shown on cards)', type: 'text', max: 200 },
    { name: 'description', label: 'Description', type: 'textarea', max: 4000 },
    { name: 'banner', label: 'Banner photo', type: 'image' },
    { name: 'gallery', label: 'Gallery photos (up to 8 at a time)', type: 'gallery' },
    { name: 'sort', label: 'Order (small number shows first)', type: 'number', default: 0 },
    { name: 'visible', label: 'Show on website', type: 'checkbox' },
  ],
  cols: [
    { label: 'Name', get: (r) => r.name },
    { label: 'Category', get: (r) => r.cat_name },
    { label: 'Shown', get: (r) => (r.visible ? 'Yes' : 'Hidden') },
  ],
});
itemResource({
  table: 'products', singular: 'Product', plural: 'Products', catType: 'product', publicPath: '/product/',
  fields: [
    { name: 'name', label: 'Name', type: 'text', required: true },
    { name: 'category_id', label: 'Category', type: 'select', required: true },
    { name: 'price', label: 'Price in Rs (leave empty for "Price on request")', type: 'number', nullable: true, step: '0.01' },
    { name: 'stock', label: 'Stock', type: 'number', default: 0 },
    { name: 'description', label: 'Description', type: 'textarea', max: 4000 },
    { name: 'photos', label: 'Photos (up to 8 at a time)', type: 'gallery' },
    { name: 'sort', label: 'Order (small number shows first)', type: 'number', default: 0 },
    { name: 'visible', label: 'Show on website', type: 'checkbox' },
  ],
  cols: [
    { label: 'Name', get: (r) => r.name },
    { label: 'Category', get: (r) => r.cat_name },
    { label: 'Price', get: (r) => (r.price === null ? 'On request' : `Rs ${Number(r.price).toLocaleString('en-PK')}`) },
    { label: 'Shown', get: (r) => (r.visible ? 'Yes' : 'Hidden') },
  ],
});

// ---------- media library ----------
router.get('/media', (req, res) => {
  const rows = db.prepare('SELECT * FROM media ORDER BY id DESC LIMIT 200').all();
  view(req, res, 'media', { title: 'Media', active: 'media', rows: rows.map((m) => ({ ...m, kb: Math.round(m.size / 1024) })) });
});
router.post('/media', upload.array('photos', 12), auth.csrfCheck, async (req, res) => {
  let saved = 0;
  for (const f of req.files || []) { try { await saveImage(f); saved += 1; } catch { /* skip */ } }
  if (!saved) return fail(res, '/admin/media', 'No valid photos were uploaded (JPG, PNG or WebP, up to 8 MB each).');
  go(res, '/admin/media', `${saved} photo(s) uploaded.`);
});
router.post('/media/:id/delete', auth.csrfCheck, (req, res) => {
  const row = db.prepare('SELECT filename FROM media WHERE id = ?').get(req.params.id);
  if (row) deleteImage(row.filename);
  go(res, '/admin/media', 'Photo deleted.');
});

// ---------- site settings ----------
const SETTING_FIELDS = [
  { name: 'business_name', label: 'Business name', type: 'text' },
  { name: 'tagline', label: 'Tagline', type: 'text' },
  { name: 'announcement', label: 'Announcement bar (leave empty to hide)', type: 'text' },
  { name: 'email', label: 'Business email', type: 'email' },
  { name: 'phone', label: 'Phone', type: 'text' },
  { name: 'whatsapp', label: 'WhatsApp number (with country code)', type: 'text' },
  { name: 'office', label: 'Office address', type: 'text' },
  { name: 'service_area', label: 'Service areas', type: 'text' },
  { name: 'site_visit_fee', label: 'Site visit fee text', type: 'text' },
  { name: 'jazzcash_number', label: 'JazzCash number', type: 'text' },
  { name: 'jazzcash_title', label: 'JazzCash account title', type: 'text' },
  { name: 'bank_name', label: 'Bank name', type: 'text' },
  { name: 'bank_title', label: 'Bank account title', type: 'text' },
  { name: 'bank_account', label: 'Bank account number', type: 'text' },
  { name: 'iban', label: 'IBAN', type: 'text' },
  { name: 'qr_image', label: 'Payment QR image', type: 'image' },
  { name: 'instagram', label: 'Instagram link (https://...)', type: 'text' },
  { name: 'facebook', label: 'Facebook link (https://...)', type: 'text' },
  { name: 'tiktok', label: 'TikTok link (https://...)', type: 'text' },
];
router.get('/settings', (req, res) => {
  const s = db.getSettings();
  view(req, res, 'form', {
    title: 'Site settings', active: 'settings', action: '/admin/settings', submit: 'Save settings',
    fields: SETTING_FIELDS.map((f) => ({ ...f, value: s[f.name] || '' })),
  });
});
router.post('/settings', upload.fields([{ name: 'qr_image', maxCount: 1 }]), auth.csrfCheck, async (req, res) => {
  const current = db.getSettings();
  for (const f of SETTING_FIELDS) {
    if (f.type === 'image') {
      let cur = current[f.name] || '';
      if (req.body[`remove_${f.name}`]) cur = '';
      const file = req.files && req.files[f.name] && req.files[f.name][0];
      if (file) { try { cur = await saveImage(file); } catch { /* ignore bad file */ } }
      db.setSetting(f.name, cur);
      continue;
    }
    let v = String(req.body[f.name] || '').trim().slice(0, 200);
    if (['instagram', 'facebook', 'tiktok'].includes(f.name) && v && !/^https?:\/\//i.test(v)) v = '';
    db.setSetting(f.name, v);
  }
  go(res, '/admin/settings', 'Settings saved.');
});

// ---------- appearance (theme customize) ----------
router.get('/appearance', (req, res) => {
  const name = themes.activeThemeName();
  const manifest = themes.readManifest(name);
  const values = themes.themeSettings(name);
  view(req, res, 'appearance', {
    title: 'Appearance', active: 'appearance', action: '/admin/appearance',
    theme: { id: name, name: manifest.name, version: manifest.version },
    themes: themes.listThemes().map((t) => ({ id: t.id, name: t.name, version: t.version, active: t.id === name })),
    fields: (manifest.settings || []).map((s) => ({ ...s, name: s.id, value: values[s.id] })),
  });
});
router.post('/appearance', auth.csrfCheck, (req, res) => {
  const name = themes.activeThemeName();
  db.setSetting(`theme:${name}`, JSON.stringify(themes.cleanThemeSettings(name, req.body)));
  go(res, '/admin/appearance', 'Appearance saved.');
});
router.post('/appearance/activate', auth.csrfCheck, (req, res) => {
  const id = String(req.body.theme || '');
  if (!themes.themeExists(id)) return fail(res, '/admin/appearance', 'Theme not found.');
  db.setSetting('active_theme', id);
  go(res, '/admin/appearance', 'Theme published.');
});

// ---------- account ----------
router.get('/account', (req, res) => view(req, res, 'account', { title: 'My account', active: 'account' }));
router.post('/account', auth.csrfCheck, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.user_id);
  const { current, password, confirm } = req.body;
  if (!auth.verifyPassword(String(current || ''), user.password_hash)) return fail(res, '/admin/account', 'Current password is wrong.');
  if (String(password || '').length < 10) return fail(res, '/admin/account', 'New password must be at least 10 characters.');
  if (password !== confirm) return fail(res, '/admin/account', 'The two new passwords do not match.');
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(auth.hashPassword(password), user.id);
  go(res, '/admin/account', 'Password changed.');
});

module.exports = router;

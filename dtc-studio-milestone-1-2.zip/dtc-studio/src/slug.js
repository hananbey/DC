const db = require('./db');
function slugify(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'item';
}
// table name must come from our own code, never from user input
function uniqueSlug(table, text, extraWhere = '', extraParams = []) {
  const base = slugify(text);
  let slug = base;
  let n = 2;
  while (db.prepare(`SELECT 1 FROM ${table} WHERE slug = ? ${extraWhere}`).get(slug, ...extraParams)) {
    slug = `${base}-${n++}`;
  }
  return slug;
}
module.exports = { slugify, uniqueSlug };

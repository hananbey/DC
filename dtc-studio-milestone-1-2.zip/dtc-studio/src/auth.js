const crypto = require('crypto');
const db = require('./db');

const COOKIE = 'dtc_sid';
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}
function verifyPassword(password, stored) {
  const [alg, salt, hash] = String(stored).split('$');
  if (alg !== 'scrypt' || !salt || !hash) return false;
  const expected = Buffer.from(hash, 'hex');
  const actual = crypto.scryptSync(password, salt, expected.length);
  return crypto.timingSafeEqual(expected, actual);
}

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function cookieString(value, maxAgeSeconds) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  return `${COOKIE}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSeconds}${secure}`;
}

function loadSession(req, res, next) {
  req.session = null;
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (token) {
    const row = db.prepare(`
      SELECT s.token, s.csrf, s.user_id, u.email, u.name, u.role
      FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token = ? AND s.expires_at > ?`).get(token, Date.now());
    if (row) req.session = row;
  }
  next();
}
function createSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(24).toString('hex');
  db.prepare('INSERT INTO sessions(token, user_id, csrf, expires_at) VALUES (?,?,?,?)').run(token, userId, csrf, Date.now() + SESSION_MS);
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
  res.setHeader('Set-Cookie', cookieString(token, SESSION_MS / 1000));
}
function destroySession(req, res) {
  if (req.session) db.prepare('DELETE FROM sessions WHERE token = ?').run(req.session.token);
  res.setHeader('Set-Cookie', cookieString('', 0));
}
function requireAdmin(req, res, next) {
  if (!req.session || req.session.role !== 'admin') return res.redirect('/admin/login');
  next();
}
// Must run AFTER the body (urlencoded or multer) has been parsed.
function csrfCheck(req, res, next) {
  const sent = req.body && req.body._csrf;
  if (!req.session || !sent || sent !== req.session.csrf) {
    return res.status(403).send('This form has expired or is invalid. Please go back, refresh the page and try again.');
  }
  next();
}

// Very small in-memory login limiter: 10 tries per 15 minutes per IP.
const attempts = new Map();
function loginLimiter(req, res, next) {
  const now = Date.now();
  const key = req.ip;
  let rec = attempts.get(key);
  if (!rec || rec.reset < now) rec = { count: 0, reset: now + 15 * 60 * 1000 };
  rec.count += 1;
  attempts.set(key, rec);
  if (rec.count > 10) return res.status(429).send('Too many login attempts. Please wait 15 minutes and try again.');
  next();
}
function clearLoginAttempts(req) { attempts.delete(req.ip); }

module.exports = {
  hashPassword, verifyPassword, loadSession, createSession, destroySession,
  requireAdmin, csrfCheck, loginLimiter, clearLoginAttempts,
};

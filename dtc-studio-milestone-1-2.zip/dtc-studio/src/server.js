require('dotenv').config();
const express = require('express');
const path = require('path');
const { loadSession } = require('./auth');
const { UPLOAD_DIR } = require('./media');
const admin = require('./admin');
const publicSite = require('./public');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Content-Security-Policy', [
    "default-src 'self'",
    "img-src 'self' data: https:",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    'font-src https://fonts.gstatic.com',
    "script-src 'self'",
    "frame-src https://www.google.com",
    "form-action 'self'",
    "base-uri 'self'",
  ].join('; '));
  next();
});

app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d', index: false }));
app.use('/admin-assets', express.static(path.join(__dirname, '..', 'public', 'admin'), { index: false }));
app.use(loadSession);
app.use('/admin', admin);
app.use(publicSite);

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  if (err && err.code === 'LIMIT_FILE_SIZE') return res.status(413).send('A photo is too large (maximum 8 MB each).');
  res.status(500).send('Something went wrong. Please go back and try again.');
});

module.exports = app;

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  app.listen(port, () => {
    console.log(`\nDTC Studio is running.\n  Website: http://localhost:${port}\n  Admin:   http://localhost:${port}/admin\n`);
  });
}

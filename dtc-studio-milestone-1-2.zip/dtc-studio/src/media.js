const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const db = require('./db');

let sharp = null;
try { sharp = require('sharp'); } catch { /* images are then saved as uploaded */ }

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 12 },
  fileFilter: (req, file, cb) => cb(null, ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)),
});

function detectType(buf) {
  if (buf.length > 12 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { ext: '.jpg', mime: 'image/jpeg' };
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { ext: '.png', mime: 'image/png' };
  if (buf.length > 12 && buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') return { ext: '.webp', mime: 'image/webp' };
  return null;
}

// Saves an uploaded image (resized to max 1200px, converted to WebP when sharp is available).
// Returns the stored filename. Throws if the file is not a real image.
async function saveImage(file) {
  const type = detectType(file.buffer);
  if (!type) throw new Error('Not a valid JPG, PNG or WebP image.');
  const id = crypto.randomBytes(8).toString('hex');
  let name, buf, width = null, height = null, mime = type.mime;
  if (sharp) {
    buf = await sharp(file.buffer, { failOn: 'none' }).rotate().resize({ width: 1200, withoutEnlargement: true }).webp({ quality: 80 }).toBuffer();
    const meta = await sharp(buf).metadata();
    width = meta.width; height = meta.height; name = id + '.webp'; mime = 'image/webp';
  } else {
    buf = file.buffer; name = id + type.ext;
  }
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  db.prepare('INSERT INTO media(filename, original_name, mime, size, width, height) VALUES (?,?,?,?,?,?)')
    .run(name, String(file.originalname || '').slice(0, 200), mime, buf.length, width, height);
  return name;
}

function deleteImage(filename) {
  if (!/^[a-f0-9]{16}\.(webp|jpg|png)$/.test(filename)) return;
  db.prepare('DELETE FROM media WHERE filename = ?').run(filename);
  fs.rmSync(path.join(UPLOAD_DIR, filename), { force: true });
}

module.exports = { upload, saveImage, deleteImage, UPLOAD_DIR };

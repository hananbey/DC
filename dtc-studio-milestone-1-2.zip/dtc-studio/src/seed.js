require('dotenv').config();
const db = require('./db');
const { hashPassword } = require('./auth');
const { slugify, uniqueSlug } = require('./slug');
const seed = require('./seed-data.json');

function createAdmin() {
  if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0) return console.log('Admin user already exists - skipped.');
  const email = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || '');
  if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 10 || /choose-a-long-password/.test(password)) {
    console.error('\nPlease open your .env file and set ADMIN_EMAIL and a real ADMIN_PASSWORD (at least 10 characters), then run "npm run setup" again.\n');
    process.exit(1);
  }
  db.prepare('INSERT INTO users(email, name, password_hash, role) VALUES (?,?,?,?)').run(email, 'Admin', hashPassword(password), 'admin');
  console.log(`Admin user created: ${email}`);
}

function seedContent() {
  if (db.prepare('SELECT COUNT(*) AS n FROM categories').get().n > 0) return console.log('Content already exists - skipped.');
  const insCat = db.prepare('INSERT INTO categories(type, slug, name, sort) VALUES (?,?,?,?)');
  const insService = db.prepare('INSERT INTO services(category_id, slug, name, summary, sort) VALUES (?,?,?,?,?)');
  const insProduct = db.prepare('INSERT INTO products(category_id, slug, name, price, stock, sort) VALUES (?,?,?,?,?,?)');
  const run = db.transaction(() => {
    const order = ['wedding', 'special', 'balloons', 'fireworks'];
    order.forEach((key, i) => {
      const catName = seed.cats[key];
      const cat = insCat.run('service', slugify(catName), catName, i + 1);
      seed.services[key].forEach((name, j) => {
        insService.run(cat.lastInsertRowid, uniqueSlug('services', name), name, `Beautiful ${name.toLowerCase()} decoration by Decorate To Celebrate.`, j + 1);
      });
    });
    Object.entries(seed.products).forEach(([slug, [catName, names]], i) => {
      const cat = insCat.run('product', slug, catName, i + 1);
      names.forEach((name, j) => insProduct.run(cat.lastInsertRowid, uniqueSlug('products', name), name, null, 0, j + 1));
    });
  });
  run();
  console.log('Starter categories, services and products added.');
}

createAdmin();
seedContent();
console.log('\nSetup finished. Start the site with: npm start\n');

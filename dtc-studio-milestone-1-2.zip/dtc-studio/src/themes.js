const fs = require('fs');
const path = require('path');
const { Liquid } = require('liquidjs');
const db = require('./db');

const THEMES_DIR = path.join(__dirname, '..', 'themes');
const PROD = process.env.NODE_ENV === 'production';
const engines = new Map();

function themeExists(name) {
  return /^[a-z0-9-]+$/.test(String(name)) && fs.existsSync(path.join(THEMES_DIR, name, 'theme.json'));
}
function activeThemeName() {
  const name = db.getSettings().active_theme;
  return themeExists(name) ? name : 'dtc-luxe';
}
function readManifest(name) {
  return JSON.parse(fs.readFileSync(path.join(THEMES_DIR, name, 'theme.json'), 'utf8'));
}
function listThemes() {
  return fs.readdirSync(THEMES_DIR).filter(themeExists).map((n) => ({ id: n, ...readManifest(n) }));
}
function themeSettings(name) {
  const manifest = readManifest(name);
  let saved = {};
  try { saved = JSON.parse(db.getSettings()[`theme:${name}`] || '{}'); } catch { /* ignore */ }
  const out = {};
  for (const s of manifest.settings || []) out[s.id] = saved[s.id] !== undefined ? saved[s.id] : s.default;
  return out;
}
// Only accept values the theme manifest allows (colours, short text, listed options).
function cleanThemeSettings(name, body) {
  const manifest = readManifest(name);
  const out = {};
  for (const s of manifest.settings || []) {
    let v = body[s.id];
    if (v === undefined) { out[s.id] = s.default; continue; }
    v = String(v).trim();
    if (s.type === 'color') out[s.id] = /^#[0-9a-fA-F]{6}$/.test(v) ? v : s.default;
    else if (s.type === 'select') out[s.id] = (s.options || []).some((o) => o.value === v) ? v : s.default;
    else if (s.type === 'url') out[s.id] = v === '' || /^https:\/\/[^\s"'()<>]+$/.test(v) ? v.slice(0, 300) : s.default;
    else out[s.id] = v.slice(0, s.type === 'textarea' ? 600 : 200);
  }
  return out;
}

function engineFor(name) {
  if (!PROD || !engines.has(name)) {
    const dir = path.join(THEMES_DIR, name);
    engines.set(name, new Liquid({
      root: [path.join(dir, 'templates'), path.join(dir, 'layout')],
      partials: [path.join(dir, 'sections')],
      extname: '.liquid',
      outputEscape: 'escape',
      cache: PROD,
    }));
  }
  return engines.get(name);
}

async function renderPage(themeName, template, data) {
  const engine = engineFor(themeName);
  const content = await engine.renderFile(template, data);
  return engine.renderFile('theme', { ...data, content_for_layout: content });
}

module.exports = {
  THEMES_DIR, themeExists, activeThemeName, readManifest, listThemes,
  themeSettings, cleanThemeSettings, renderPage,
};
